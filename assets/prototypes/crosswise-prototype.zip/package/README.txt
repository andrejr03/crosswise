CROSSWISE — AI Document Reconciliation
Final source package · Concept 2 (approved)
===========================================

This package contains ONLY the approved Concept 2 design.

CONTENTS
--------
Crosswise-Concept2.png
    Final showcase image — 1080 x 1350 px (4:5 portrait), PNG.
    Rendered directly from the design source. Ready to post.

Crosswise-Concept2-Offline.html
    Fully self-contained, offline version of the Concept 2 design.
    Fonts and runtime are embedded — open it in any browser, no
    internet or extra files required.

source/
    Editable source:
      Crosswise-Concept2.html   — the design (markup + inline CSS)
      support.js                — required runtime JS (must sit
                                  beside the HTML to run)
    Open Crosswise-Concept2.html in a browser to run it. It loads
    the Newsreader + JetBrains Mono fonts from Google Fonts.

NOTES
-----
- CSS: all styling is authored inline in the HTML (no separate
  stylesheet).
- Fonts (assets): Newsreader (serif) + JetBrains Mono (mono).
  Loaded from Google Fonts in source/, embedded in the offline file.
- Palette: warm graphite, bone, clay, sage + amber signal colors
  (no saturated blue).
- Canvas size: 1080 x 1350.
